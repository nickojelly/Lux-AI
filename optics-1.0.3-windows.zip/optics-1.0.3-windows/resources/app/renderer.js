"use strict";

require("./modules/__startup_renderer");
